#FOLDER AND FILES ROLES:

RESSOURCES:
        -css (folder)
        -js  (folder)

IMAGES: 
        -Auth.png (unused)
        -Calendar.png (unused)
        -Comments.png (unused)
        -Confirmation.png (unused)
        tt.png  (unused)


MAIN FILES FOR EXECUTION:

==> tt.js